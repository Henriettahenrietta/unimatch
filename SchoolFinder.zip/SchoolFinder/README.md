# UniMactCameroon — Android App

A self-contained Android application for discovering, comparing, rating, and
navigating to educational institutions in Cameroon. Built from the School Finder
SRS as a fully offline, runnable app — no backend server, API keys, or internet
connection required to build and run (only the first Gradle sync needs internet
to download dependencies).

## Tech stack

- **Language:** Java (100%)
- **UI:** Android View system with XML layouts + Material Components (Material 3 theme)
- **Lists:** RecyclerView with adapters
- **Navigation:** Activities + Fragments with a BottomNavigationView
- **Local database:** Room (SQLite) with `annotationProcessor`
- **Architecture:** Repository + LiveData, background `ExecutorService` for writes
- **Min SDK:** 24 · **Target/Compile SDK:** 35 · **JDK:** 17
- **Gradle:** 8.9 · **Android Gradle Plugin:** 8.7.3

> Note: the UI is built with the traditional Android **View system** rather than
> Jetpack Compose, because Compose is Kotlin-only. This keeps the project pure
> Java as required by the SRS.

## How to run

1. Open **Android Studio** (latest stable).
2. **File → Open** and select this `SchoolFinder` folder.
3. Let Gradle sync (first sync downloads dependencies — internet required once).
4. Pick an emulator or device and press **Run**. The app seeds its local
   database with sample institutions on first launch.

## Demo accounts

- **Administrator:** `admin@schoolfinder.com` / `admin123`
- **Student:** register any account in-app, or tap **Continue as Guest**.

## Features

- **Login / Register / Guest** — local accounts stored in Room.
- **Home** — searchable, filterable (by category) and sortable list of schools.
- **School detail** — info, star rating, programs, facilities, reviews, plus
  **Open in Maps** (via a `geo:` intent — no Maps API key needed), **Call**, and
  **Website** actions.
- **Compare** — pick two schools and see a side-by-side comparison that
  highlights the cheaper tuition and the higher rating.
- **Favorites** — students can save schools (guests are prompted to log in).
- **Reviews** — students submit star + text reviews.
- **Profile** — shows role; admins get an **Admin Dashboard** entry point.
- **Admin Dashboard** — overview stats, review moderation (approve/hide/delete),
  and full **CRUD** management of schools (add / edit / delete).

## What stands in for the SRS backend

The SRS specifies Firebase Auth, a Spring Boot + PostgreSQL backend, Cloudinary,
and Google Maps. To keep the app runnable out of the box with no keys or server,
those are replaced locally:

| SRS component            | In this build                                            |
|--------------------------|----------------------------------------------------------|
| PostgreSQL / Spring Boot | Room (local SQLite) via a Repository layer               |
| Firebase Authentication  | Local accounts in Room + SharedPreferences session       |
| Cloudinary image hosting | Generated colored initial "avatars" (no network images)  |
| Google Maps SDK          | `geo:` map intent with a Google Maps web fallback        |

All of these are isolated behind the `data` / `session` layers, so each could be
swapped for the real remote service without touching the UI.

## Project structure

```
app/src/main/
├─ java/com/schoolfinder/app/
│  ├─ UniMactApp.java            # Application: seeds the database
│  ├─ data/                      # Room entities, DAOs, Converters, DB, Repository, SeedData
│  ├─ session/                   # SessionManager + UserSession
│  ├─ adapter/                   # RecyclerView adapters
│  └─ ui/                        # Activities, Fragments, UiUtils
└─ res/
   ├─ layout/                    # XML layouts
   ├─ drawable/                  # vector icons + shape backgrounds
   ├─ menu/                      # bottom navigation menu
   └─ values[/-night]/          # colors, strings, themes (maroon + white)
```

## Theme

Maroon (`#800000`) primary on a white background, with a matching dark theme.
