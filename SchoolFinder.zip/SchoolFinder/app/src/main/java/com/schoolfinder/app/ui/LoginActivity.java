package com.schoolfinder.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.schoolfinder.app.R;
import com.schoolfinder.app.data.Repository;
import com.schoolfinder.app.session.SessionManager;
import com.schoolfinder.app.session.UserSession;

public class LoginActivity extends AppCompatActivity {

    private SessionManager session;
    private Repository repo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        session = SessionManager.getInstance(this);
        repo = Repository.getInstance(this);

        if (session.isLoggedIn()) {
            goMain();
            return;
        }

        setContentView(R.layout.activity_login);

        TextInputEditText etEmail = findViewById(R.id.etEmail);
        TextInputEditText etPassword = findViewById(R.id.etPassword);
        MaterialButton btnLogin = findViewById(R.id.btnLogin);
        MaterialButton btnGuest = findViewById(R.id.btnGuest);
        MaterialButton btnGoRegister = findViewById(R.id.btnGoRegister);

        btnLogin.setOnClickListener(v -> {
            String email = textOf(etEmail);
            String password = textOf(etPassword);
            if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
                Toast.makeText(this, getString(R.string.enter_email_password), Toast.LENGTH_SHORT).show();
                return;
            }
            repo.login(email, password, user -> {
                if (user == null) {
                    Toast.makeText(this, getString(R.string.invalid_login), Toast.LENGTH_SHORT).show();
                } else {
                    session.signIn(new UserSession(user.email, user.name, user.role));
                    goMain();
                }
            });
        });

        btnGuest.setOnClickListener(v -> {
            session.continueAsGuest();
            goMain();
        });

        btnGoRegister.setOnClickListener(v ->
                startActivity(new Intent(this, RegisterActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        // After returning from a successful registration the session may be set.
        if (session != null && session.isLoggedIn()) {
            goMain();
        }
    }

    private void goMain() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    private String textOf(TextInputEditText et) {
        return et.getText() == null ? "" : et.getText().toString().trim();
    }
}
