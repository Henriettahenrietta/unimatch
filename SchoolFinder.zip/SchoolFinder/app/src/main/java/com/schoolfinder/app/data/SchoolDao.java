package com.schoolfinder.app.data;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface SchoolDao {

    @Query("SELECT * FROM schools ORDER BY name ASC")
    LiveData<List<SchoolEntity>> observeAll();

    @Query("SELECT * FROM schools WHERE id = :id LIMIT 1")
    LiveData<SchoolEntity> observeById(int id);

    @Query("SELECT * FROM schools WHERE id = :id LIMIT 1")
    SchoolEntity getByIdSync(int id);

    @Query("SELECT COUNT(*) FROM schools")
    int count();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(SchoolEntity school);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<SchoolEntity> schools);

    @Update
    void update(SchoolEntity school);

    @Delete
    void delete(SchoolEntity school);
}
