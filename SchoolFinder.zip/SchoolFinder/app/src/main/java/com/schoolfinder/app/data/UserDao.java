package com.schoolfinder.app.data;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface UserDao {

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    UserEntity getByEmail(String email);

    @Query("SELECT * FROM users WHERE email = :email AND password = :password LIMIT 1")
    UserEntity login(String email, String password);

    @Query("SELECT COUNT(*) FROM users")
    int count();

    @Query("SELECT * FROM users ORDER BY name ASC")
    LiveData<List<UserEntity>> observeAll();

    @Insert(onConflict = OnConflictStrategy.ABORT)
    long insert(UserEntity user);
}
