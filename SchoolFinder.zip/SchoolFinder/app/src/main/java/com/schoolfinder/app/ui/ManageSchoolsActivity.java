package com.schoolfinder.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.schoolfinder.app.R;
import com.schoolfinder.app.adapter.ManageSchoolAdapter;
import com.schoolfinder.app.data.Repository;
import com.schoolfinder.app.data.SchoolEntity;
import com.schoolfinder.app.session.SessionManager;
import com.schoolfinder.app.session.UserSession;

public class ManageSchoolsActivity extends AppCompatActivity {

    static final String EXTRA_ID = "school_id";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        UserSession current = SessionManager.getInstance(this).getCurrent();
        if (current == null || !current.isAdmin()) {
            Toast.makeText(this, getString(R.string.admins_only), Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        setContentView(R.layout.activity_manage_schools);
        final Repository repo = Repository.getInstance(this);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        RecyclerView recycler = findViewById(R.id.recycler);
        recycler.setLayoutManager(new LinearLayoutManager(this));

        ManageSchoolAdapter adapter = new ManageSchoolAdapter(new ManageSchoolAdapter.Listener() {
            @Override
            public void onEdit(SchoolEntity school) {
                Intent i = new Intent(ManageSchoolsActivity.this, AddEditSchoolActivity.class);
                i.putExtra(EXTRA_ID, school.id);
                startActivity(i);
            }

            @Override
            public void onDelete(final SchoolEntity school) {
                new AlertDialog.Builder(ManageSchoolsActivity.this)
                        .setTitle(getString(R.string.delete_school))
                        .setMessage(getString(R.string.delete_confirm, school.name))
                        .setPositiveButton(getString(R.string.delete), (d, w) -> repo.deleteSchool(school))
                        .setNegativeButton(getString(R.string.cancel), null)
                        .show();
            }
        });
        recycler.setAdapter(adapter);

        repo.observeSchools().observe(this, adapter::setItems);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(v ->
                startActivity(new Intent(this, AddEditSchoolActivity.class)));
    }
}
