package com.schoolfinder.app.ui;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.TextInputEditText;
import com.schoolfinder.app.R;
import com.schoolfinder.app.adapter.SchoolAdapter;
import com.schoolfinder.app.data.Repository;
import com.schoolfinder.app.data.SchoolEntity;
import com.schoolfinder.app.session.SessionManager;
import com.schoolfinder.app.session.UserSession;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class HomeFragment extends Fragment {

    private static final int SORT_TOP = 0;
    private static final int SORT_LOW = 1;
    private static final int SORT_HIGH = 2;
    private static final int SORT_NAME = 3;

    private Repository repo;
    private SessionManager session;
    private SchoolAdapter adapter;

    private List<SchoolEntity> allSchools = new ArrayList<>();
    private String query = "";
    private String categoryFilter = null;   // null = All
    private int sortCode = SORT_TOP;

    private TextView tvCount;
    private ChipGroup chipCategories;
    private MaterialButton btnSort;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        repo = Repository.getInstance(requireContext());
        session = SessionManager.getInstance(requireContext());

        UserSession current = session.getCurrent();
        boolean guest = current == null || current.isGuest();
        final String email = current == null ? "guest" : current.email;

        RecyclerView recycler = view.findViewById(R.id.recycler);
        recycler.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new SchoolAdapter(new SchoolAdapter.Listener() {
            @Override
            public void onClick(SchoolEntity school) {
                SchoolDetailActivity.start(requireContext(), school.id);
            }

            @Override
            public void onToggleFavorite(SchoolEntity school) {
                repo.toggleFavorite(email, school.id);
            }
        });
        adapter.setShowFavorite(!guest);
        recycler.setAdapter(adapter);

        tvCount = view.findViewById(R.id.tvCount);
        chipCategories = view.findViewById(R.id.chipCategories);
        TextInputEditText etSearch = view.findViewById(R.id.etSearch);
        btnSort = view.findViewById(R.id.btnSort);
        updateSortLabel();

        etSearch.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {
                query = s.toString().trim().toLowerCase(Locale.getDefault());
                applyFilters();
            }
            public void afterTextChanged(Editable s) {}
        });

        btnSort.setOnClickListener(v -> {
            PopupMenu menu = new PopupMenu(requireContext(), btnSort);
            menu.getMenu().add(0, SORT_TOP, 0, getString(R.string.sort_top_rated));
            menu.getMenu().add(0, SORT_LOW, 1, getString(R.string.sort_lowest_tuition));
            menu.getMenu().add(0, SORT_HIGH, 2, getString(R.string.sort_highest_tuition));
            menu.getMenu().add(0, SORT_NAME, 3, getString(R.string.sort_name));
            menu.setOnMenuItemClickListener(item -> {
                sortCode = item.getItemId();
                updateSortLabel();
                applyFilters();
                return true;
            });
            menu.show();
        });

        if (!guest) {
            repo.observeFavoriteIds(email).observe(getViewLifecycleOwner(),
                    ids -> adapter.setFavorites(ids));
        }

        repo.observeSchools().observe(getViewLifecycleOwner(), schools -> {
            allSchools = schools == null ? new ArrayList<>() : schools;
            buildCategories();
            applyFilters();
        });
    }

    private String sortName(int code) {
        switch (code) {
            case SORT_LOW: return getString(R.string.sort_lowest_tuition);
            case SORT_HIGH: return getString(R.string.sort_highest_tuition);
            case SORT_NAME: return getString(R.string.sort_name);
            default: return getString(R.string.sort_top_rated);
        }
    }

    private void updateSortLabel() {
        btnSort.setText(getString(R.string.sort_label, sortName(sortCode)));
    }

    private void buildCategories() {
        if (allSchools.isEmpty()) return;
        Set<String> cats = new LinkedHashSet<>();
        for (SchoolEntity s : allSchools) {
            if (s.category != null && !s.category.isEmpty()) cats.add(s.category);
        }
        chipCategories.removeAllViews();

        Chip all = new Chip(requireContext());
        all.setText(getString(R.string.filter_all));
        all.setCheckable(true);
        all.setChecked(categoryFilter == null);
        all.setOnClickListener(v -> {
            categoryFilter = null;
            applyFilters();
        });
        chipCategories.addView(all);

        for (final String c : cats) {
            Chip chip = new Chip(requireContext());
            chip.setText(UiUtils.localizedCategory(requireContext(), c));
            chip.setCheckable(true);
            chip.setChecked(c.equals(categoryFilter));
            chip.setOnClickListener(v -> {
                categoryFilter = c;
                applyFilters();
            });
            chipCategories.addView(chip);
        }
    }

    private void applyFilters() {
        if (adapter == null) return;
        List<SchoolEntity> filtered = new ArrayList<>();
        for (SchoolEntity s : allSchools) {
            boolean matchesQuery = query.isEmpty()
                    || s.name.toLowerCase(Locale.getDefault()).contains(query)
                    || (s.location != null && s.location.toLowerCase(Locale.getDefault()).contains(query));
            boolean matchesCat = categoryFilter == null || categoryFilter.equals(s.category);
            if (matchesQuery && matchesCat) filtered.add(s);
        }

        switch (sortCode) {
            case SORT_LOW:
                Collections.sort(filtered, Comparator.comparingInt(a -> a.tuition));
                break;
            case SORT_HIGH:
                Collections.sort(filtered, (a, b) -> Integer.compare(b.tuition, a.tuition));
                break;
            case SORT_NAME:
                Collections.sort(filtered, Comparator.comparing(a -> a.name.toLowerCase(Locale.getDefault())));
                break;
            default:
                Collections.sort(filtered, (a, b) -> Double.compare(b.baseRating, a.baseRating));
                break;
        }

        adapter.setItems(filtered);
        if (tvCount != null) {
            int n = filtered.size();
            tvCount.setText(getResources().getQuantityString(R.plurals.school_count, n, n));
        }
    }
}
