package com.schoolfinder.app.ui;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.TextInputEditText;
import com.schoolfinder.app.R;
import com.schoolfinder.app.adapter.SchoolAdapter;
import com.schoolfinder.app.data.Repository;
import com.schoolfinder.app.data.SchoolEntity;
import com.schoolfinder.app.session.SessionManager;
import com.schoolfinder.app.session.UserSession;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class HomeFragment extends Fragment {

    private Repository repo;
    private SessionManager session;
    private SchoolAdapter adapter;

    private List<SchoolEntity> allSchools = new ArrayList<>();
    private String query = "";
    private String category = "All";
    private String sort = "Top rated";

    private TextView tvCount;
    private ChipGroup chipCategories;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        repo = Repository.getInstance(requireContext());
        session = SessionManager.getInstance(requireContext());

        UserSession current = session.getCurrent();
        boolean guest = current == null || current.isGuest();
        final String email = current == null ? "guest" : current.email;

        RecyclerView recycler = view.findViewById(R.id.recycler);
        recycler.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new SchoolAdapter(new SchoolAdapter.Listener() {
            @Override
            public void onClick(SchoolEntity school) {
                SchoolDetailActivity.start(requireContext(), school.id);
            }

            @Override
            public void onToggleFavorite(SchoolEntity school) {
                repo.toggleFavorite(email, school.id);
            }
        });
        adapter.setShowFavorite(!guest);
        recycler.setAdapter(adapter);

        tvCount = view.findViewById(R.id.tvCount);
        chipCategories = view.findViewById(R.id.chipCategories);
        TextInputEditText etSearch = view.findViewById(R.id.etSearch);
        final MaterialButton btnSort = view.findViewById(R.id.btnSort);

        etSearch.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {
                query = s.toString().trim().toLowerCase(Locale.getDefault());
                applyFilters();
            }
            public void afterTextChanged(Editable s) {}
        });

        btnSort.setOnClickListener(v -> {
            PopupMenu menu = new PopupMenu(requireContext(), btnSort);
            String[] options = {"Top rated", "Lowest tuition", "Highest tuition", "Name (A-Z)"};
            for (String o : options) menu.getMenu().add(o);
            menu.setOnMenuItemClickListener(item -> {
                sort = item.getTitle().toString();
                btnSort.setText("Sort: " + sort);
                applyFilters();
                return true;
            });
            menu.show();
        });

        if (!guest) {
            repo.observeFavoriteIds(email).observe(getViewLifecycleOwner(),
                    ids -> adapter.setFavorites(ids));
        }

        repo.observeSchools().observe(getViewLifecycleOwner(), schools -> {
            allSchools = schools == null ? new ArrayList<>() : schools;
            buildCategories();
            applyFilters();
        });
    }

    private void buildCategories() {
        if (allSchools.isEmpty()) return;
        Set<String> cats = new LinkedHashSet<>();
        cats.add("All");
        for (SchoolEntity s : allSchools) {
            if (s.category != null && !s.category.isEmpty()) cats.add(s.category);
        }
        chipCategories.removeAllViews();
        for (String c : cats) {
            Chip chip = new Chip(requireContext());
            chip.setText(c);
            chip.setCheckable(true);
            chip.setChecked(c.equals(category));
            chip.setOnClickListener(v -> {
                category = c;
                applyFilters();
            });
            chipCategories.addView(chip);
        }
    }

    private void applyFilters() {
        if (adapter == null) return;
        List<SchoolEntity> filtered = new ArrayList<>();
        for (SchoolEntity s : allSchools) {
            boolean matchesQuery = query.isEmpty()
                    || s.name.toLowerCase(Locale.getDefault()).contains(query)
                    || (s.location != null && s.location.toLowerCase(Locale.getDefault()).contains(query));
            boolean matchesCat = category.equals("All") || category.equals(s.category);
            if (matchesQuery && matchesCat) filtered.add(s);
        }

        switch (sort) {
            case "Lowest tuition":
                Collections.sort(filtered, Comparator.comparingInt(a -> a.tuition));
                break;
            case "Highest tuition":
                Collections.sort(filtered, (a, b) -> Integer.compare(b.tuition, a.tuition));
                break;
            case "Name (A-Z)":
                Collections.sort(filtered, Comparator.comparing(a -> a.name.toLowerCase(Locale.getDefault())));
                break;
            default: // Top rated
                Collections.sort(filtered, (a, b) -> Double.compare(b.baseRating, a.baseRating));
                break;
        }

        adapter.setItems(filtered);
        if (tvCount != null) {
            tvCount.setText(filtered.size() + " school" + (filtered.size() == 1 ? "" : "s"));
        }
    }
}
