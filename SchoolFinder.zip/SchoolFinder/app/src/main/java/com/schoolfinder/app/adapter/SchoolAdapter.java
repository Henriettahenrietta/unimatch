package com.schoolfinder.app.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.schoolfinder.app.R;
import com.schoolfinder.app.data.SchoolEntity;
import com.schoolfinder.app.ui.UiUtils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SchoolAdapter extends RecyclerView.Adapter<SchoolAdapter.VH> {

    public interface Listener {
        void onClick(SchoolEntity school);
        void onToggleFavorite(SchoolEntity school);
    }

    private final List<SchoolEntity> items = new ArrayList<>();
    private final Set<Integer> favoriteIds = new HashSet<>();
    private boolean showFavorite = true;
    private final Listener listener;

    public SchoolAdapter(Listener listener) {
        this.listener = listener;
    }

    public void setItems(List<SchoolEntity> list) {
        items.clear();
        if (list != null) items.addAll(list);
        notifyDataSetChanged();
    }

    public void setFavorites(List<Integer> ids) {
        favoriteIds.clear();
        if (ids != null) favoriteIds.addAll(ids);
        notifyDataSetChanged();
    }

    public void setShowFavorite(boolean show) {
        this.showFavorite = show;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_school, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        final SchoolEntity s = items.get(position);

        h.avatar.setText(UiUtils.initials(s.name));
        UiUtils.tintAvatar(h.avatar, s.name);

        h.tvName.setText(s.name);
        h.tvCategory.setText(s.category);
        h.tvMeta.setText(h.itemView.getContext().getString(R.string.meta_school, s.location, UiUtils.money(s.tuition)));
        UiUtils.renderStars(h.starRow, s.baseRating, 16);

        if (showFavorite) {
            h.btnFavorite.setVisibility(View.VISIBLE);
            boolean fav = favoriteIds.contains(s.id);
            h.btnFavorite.setImageResource(fav ? R.drawable.ic_favorite : R.drawable.ic_favorite_border);
            h.btnFavorite.setColorFilter(fav ? 0xFFE53935 : 0xFF6B5656);
            h.btnFavorite.setOnClickListener(v -> listener.onToggleFavorite(s));
        } else {
            h.btnFavorite.setVisibility(View.GONE);
        }

        h.itemView.setOnClickListener(v -> listener.onClick(s));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        final TextView avatar, tvName, tvCategory, tvMeta;
        final LinearLayout starRow;
        final ImageButton btnFavorite;

        VH(@NonNull View v) {
            super(v);
            avatar = v.findViewById(R.id.avatar);
            tvName = v.findViewById(R.id.tvName);
            tvCategory = v.findViewById(R.id.tvCategory);
            tvMeta = v.findViewById(R.id.tvMeta);
            starRow = v.findViewById(R.id.starRow);
            btnFavorite = v.findViewById(R.id.btnFavorite);
        }
    }
}
