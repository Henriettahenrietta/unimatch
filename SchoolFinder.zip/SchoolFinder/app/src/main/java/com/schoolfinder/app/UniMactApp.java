package com.schoolfinder.app;

import android.app.Application;

import com.schoolfinder.app.data.AppDatabase;
import com.schoolfinder.app.data.Repository;
import com.schoolfinder.app.data.SeedData;

/** Application entry point: prepares the database and seeds it on first launch. */
public class UniMactApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        final AppDatabase db = AppDatabase.getInstance(this);
        Repository repo = Repository.getInstance(this);
        repo.io().execute(() -> {
            if (db.schoolDao().count() == 0) {
                db.schoolDao().insertAll(SeedData.schools());
                db.reviewDao().insertAll(SeedData.sampleReviews());
            }
            if (db.userDao().count() == 0) {
                db.userDao().insert(SeedData.defaultAdmin());
            }
        });
    }
}
