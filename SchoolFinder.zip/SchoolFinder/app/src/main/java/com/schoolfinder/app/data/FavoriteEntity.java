package com.schoolfinder.app.data;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "favorites", indices = {@Index(value = {"userEmail", "schoolId"}, unique = true)})
public class FavoriteEntity {

    @PrimaryKey(autoGenerate = true)
    public int id;

    @NonNull
    public String userEmail;
    public int schoolId;

    public FavoriteEntity(@NonNull String userEmail, int schoolId) {
        this.userEmail = userEmail;
        this.schoolId = schoolId;
    }

    @Ignore
    public FavoriteEntity() {
        this.userEmail = "";
    }
}
