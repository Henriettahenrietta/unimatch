package com.schoolfinder.app.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.schoolfinder.app.R;
import com.schoolfinder.app.data.SchoolEntity;

import java.util.ArrayList;
import java.util.List;

public class ManageSchoolAdapter extends RecyclerView.Adapter<ManageSchoolAdapter.VH> {

    public interface Listener {
        void onEdit(SchoolEntity school);
        void onDelete(SchoolEntity school);
    }

    private final List<SchoolEntity> items = new ArrayList<>();
    private final Listener listener;

    public ManageSchoolAdapter(Listener listener) {
        this.listener = listener;
    }

    public void setItems(List<SchoolEntity> list) {
        items.clear();
        if (list != null) items.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_manage_school, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        final SchoolEntity s = items.get(position);
        h.tvName.setText(s.name);
        h.tvMeta.setText(s.category + "  •  $" + s.tuition + "/yr");
        h.btnEdit.setOnClickListener(v -> listener.onEdit(s));
        h.btnDelete.setOnClickListener(v -> listener.onDelete(s));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        final TextView tvName, tvMeta;
        final ImageButton btnEdit, btnDelete;

        VH(@NonNull View v) {
            super(v);
            tvName = v.findViewById(R.id.tvName);
            tvMeta = v.findViewById(R.id.tvMeta);
            btnEdit = v.findViewById(R.id.btnEdit);
            btnDelete = v.findViewById(R.id.btnDelete);
        }
    }
}
