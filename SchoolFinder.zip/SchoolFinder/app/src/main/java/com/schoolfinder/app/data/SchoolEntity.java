package com.schoolfinder.app.data;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import java.util.List;

/**
 * In the SRS the backend uses PostgreSQL. For a self-contained app that runs
 * immediately in Android Studio (no server / API keys), the same data model is
 * stored locally with Room/SQLite.
 */
@Entity(tableName = "schools")
public class SchoolEntity {

    @PrimaryKey(autoGenerate = true)
    public int id;

    @NonNull
    public String name;
    public String category;
    public String location;
    public String address;
    public double latitude;
    public double longitude;
    public int tuition;            // annual tuition in FCFA
    public List<String> programs;
    public List<String> facilities;
    public String description;
    public double baseRating;      // editorial/baseline rating before user reviews
    public String website;
    public String phone;

    public SchoolEntity(@NonNull String name, String category, String location, String address,
                        double latitude, double longitude, int tuition,
                        List<String> programs, List<String> facilities, String description,
                        double baseRating, String website, String phone) {
        this.name = name;
        this.category = category;
        this.location = location;
        this.address = address;
        this.latitude = latitude;
        this.longitude = longitude;
        this.tuition = tuition;
        this.programs = programs;
        this.facilities = facilities;
        this.description = description;
        this.baseRating = baseRating;
        this.website = website;
        this.phone = phone;
    }

    @Ignore
    public SchoolEntity() {
        this.name = "";
    }
}
