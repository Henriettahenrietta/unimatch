package com.schoolfinder.app.ui;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.schoolfinder.app.R;
import com.schoolfinder.app.data.Repository;
import com.schoolfinder.app.data.SchoolEntity;
import com.schoolfinder.app.session.SessionManager;
import com.schoolfinder.app.session.UserSession;

import java.util.ArrayList;
import java.util.List;

public class AddEditSchoolActivity extends AppCompatActivity {

    private Repository repo;
    private int schoolId = -1;
    private boolean editing = false;
    private boolean prefilled = false;

    private TextInputEditText etName, etCategory, etLocation, etAddress, etLatitude, etLongitude,
            etTuition, etPrograms, etFacilities, etBaseRating, etWebsite, etPhone, etDescription;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        UserSession current = SessionManager.getInstance(this).getCurrent();
        if (current == null || !current.isAdmin()) {
            Toast.makeText(this, "Admins only", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        setContentView(R.layout.activity_add_edit_school);
        repo = Repository.getInstance(this);

        schoolId = getIntent().getIntExtra(ManageSchoolsActivity.EXTRA_ID, -1);
        editing = schoolId != -1;

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(editing ? "Edit School" : "Add School");
        toolbar.setNavigationOnClickListener(v -> finish());

        etName = findViewById(R.id.etName);
        etCategory = findViewById(R.id.etCategory);
        etLocation = findViewById(R.id.etLocation);
        etAddress = findViewById(R.id.etAddress);
        etLatitude = findViewById(R.id.etLatitude);
        etLongitude = findViewById(R.id.etLongitude);
        etTuition = findViewById(R.id.etTuition);
        etPrograms = findViewById(R.id.etPrograms);
        etFacilities = findViewById(R.id.etFacilities);
        etBaseRating = findViewById(R.id.etBaseRating);
        etWebsite = findViewById(R.id.etWebsite);
        etPhone = findViewById(R.id.etPhone);
        etDescription = findViewById(R.id.etDescription);

        MaterialButton btnSave = findViewById(R.id.btnSave);
        btnSave.setOnClickListener(v -> save());

        if (editing) {
            repo.observeSchool(schoolId).observe(this, s -> {
                if (s != null && !prefilled) {
                    prefill(s);
                    prefilled = true;
                }
            });
        }
    }

    private void prefill(SchoolEntity s) {
        etName.setText(s.name);
        etCategory.setText(s.category);
        etLocation.setText(s.location);
        etAddress.setText(s.address);
        etLatitude.setText(String.valueOf(s.latitude));
        etLongitude.setText(String.valueOf(s.longitude));
        etTuition.setText(String.valueOf(s.tuition));
        etPrograms.setText(join(s.programs));
        etFacilities.setText(join(s.facilities));
        etBaseRating.setText(String.valueOf(s.baseRating));
        etWebsite.setText(s.website);
        etPhone.setText(s.phone);
        etDescription.setText(s.description);
    }

    private void save() {
        String name = text(etName);
        if (TextUtils.isEmpty(name)) {
            Toast.makeText(this, "School name is required", Toast.LENGTH_SHORT).show();
            return;
        }
        double rating = parseD(text(etBaseRating), 4.0);
        if (rating < 0) rating = 0;
        if (rating > 5) rating = 5;

        SchoolEntity s = new SchoolEntity(
                name,
                text(etCategory),
                text(etLocation),
                text(etAddress),
                parseD(text(etLatitude), 0.0),
                parseD(text(etLongitude), 0.0),
                (int) parseD(text(etTuition), 0),
                splitList(text(etPrograms)),
                splitList(text(etFacilities)),
                text(etDescription),
                rating,
                text(etWebsite),
                text(etPhone));

        if (editing) {
            s.id = schoolId;
            repo.updateSchool(s);
            Toast.makeText(this, "School updated", Toast.LENGTH_SHORT).show();
        } else {
            repo.addSchool(s);
            Toast.makeText(this, "School added", Toast.LENGTH_SHORT).show();
        }
        finish();
    }

    private String text(TextInputEditText et) {
        return et.getText() == null ? "" : et.getText().toString().trim();
    }

    private double parseD(String value, double def) {
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private List<String> splitList(String value) {
        List<String> list = new ArrayList<>();
        if (value == null || value.isEmpty()) return list;
        for (String part : value.split(",")) {
            String t = part.trim();
            if (!t.isEmpty()) list.add(t);
        }
        return list;
    }

    private String join(List<String> list) {
        return list == null ? "" : TextUtils.join(", ", list);
    }
}
