package com.schoolfinder.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.os.LocaleListCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.button.MaterialButton;
import com.schoolfinder.app.R;
import com.schoolfinder.app.session.SessionManager;
import com.schoolfinder.app.session.UserSession;

import java.util.Locale;

public class ProfileFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_profile, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        final SessionManager session = SessionManager.getInstance(requireContext());
        UserSession current = session.getCurrent();

        TextView avatar = view.findViewById(R.id.avatar);
        TextView tvName = view.findViewById(R.id.tvName);
        TextView tvEmail = view.findViewById(R.id.tvEmail);
        TextView tvRole = view.findViewById(R.id.tvRole);
        View cardGuest = view.findViewById(R.id.cardGuest);
        MaterialButton btnAdmin = view.findViewById(R.id.btnAdmin);
        MaterialButton btnLanguage = view.findViewById(R.id.btnLanguage);
        MaterialButton btnLogout = view.findViewById(R.id.btnLogout);

        boolean guest = current == null || current.isGuest();
        String name = (current == null || current.isGuest()) ? getString(R.string.role_guest) : current.name;

        avatar.setText(UiUtils.initials(name));
        UiUtils.tintAvatar(avatar, name);
        tvName.setText(name);

        if (guest) {
            tvEmail.setVisibility(View.GONE);
            tvRole.setText(getString(R.string.role_guest));
            cardGuest.setVisibility(View.VISIBLE);
            btnLogout.setText(getString(R.string.exit_guest));
        } else {
            tvEmail.setVisibility(View.VISIBLE);
            tvEmail.setText(current.email);
            tvRole.setText(getString(current.isAdmin() ? R.string.role_admin : R.string.role_student));
            cardGuest.setVisibility(View.GONE);
            btnLogout.setText(getString(R.string.logout));
        }

        btnAdmin.setVisibility(current != null && current.isAdmin() ? View.VISIBLE : View.GONE);
        btnAdmin.setOnClickListener(v ->
                startActivity(new Intent(requireContext(), AdminActivity.class)));

        btnLanguage.setText(getString(R.string.language) + ": " + currentLanguageName());
        btnLanguage.setOnClickListener(v -> showLanguageDialog());

        btnLogout.setOnClickListener(v -> {
            session.signOut();
            Intent i = new Intent(requireContext(), LoginActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            requireActivity().finish();
        });
    }

    private boolean isFrench() {
        LocaleListCompat locales = AppCompatDelegate.getApplicationLocales();
        String tag = locales.isEmpty()
                ? Locale.getDefault().getLanguage()
                : locales.get(0).getLanguage();
        return tag != null && tag.startsWith("fr");
    }

    private String currentLanguageName() {
        return isFrench() ? "Français" : "English";
    }

    private void showLanguageDialog() {
        final String[] options = {"English", "Français"};
        int checked = isFrench() ? 1 : 0;
        new AlertDialog.Builder(requireContext())
                .setTitle(getString(R.string.choose_language))
                .setSingleChoiceItems(options, checked, (dialog, which) -> {
                    String tag = which == 1 ? "fr" : "en";
                    dialog.dismiss();
                    AppCompatDelegate.setApplicationLocales(
                            LocaleListCompat.forLanguageTags(tag));
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }
}
