package com.schoolfinder.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.button.MaterialButton;
import com.schoolfinder.app.R;
import com.schoolfinder.app.session.SessionManager;
import com.schoolfinder.app.session.UserSession;

public class ProfileFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_profile, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        final SessionManager session = SessionManager.getInstance(requireContext());
        UserSession current = session.getCurrent();

        TextView avatar = view.findViewById(R.id.avatar);
        TextView tvName = view.findViewById(R.id.tvName);
        TextView tvEmail = view.findViewById(R.id.tvEmail);
        TextView tvRole = view.findViewById(R.id.tvRole);
        View cardGuest = view.findViewById(R.id.cardGuest);
        MaterialButton btnAdmin = view.findViewById(R.id.btnAdmin);
        MaterialButton btnLogout = view.findViewById(R.id.btnLogout);

        boolean guest = current == null || current.isGuest();
        String name = current == null ? "Guest" : current.name;

        avatar.setText(UiUtils.initials(name));
        UiUtils.tintAvatar(avatar, name);
        tvName.setText(name);

        if (guest) {
            tvEmail.setVisibility(View.GONE);
            tvRole.setText("Guest");
            cardGuest.setVisibility(View.VISIBLE);
            btnLogout.setText("Exit guest mode");
        } else {
            tvEmail.setVisibility(View.VISIBLE);
            tvEmail.setText(current.email);
            tvRole.setText(current.isAdmin() ? "Administrator" : "Registered Student");
            cardGuest.setVisibility(View.GONE);
            btnLogout.setText("Log out");
        }

        btnAdmin.setVisibility(current != null && current.isAdmin() ? View.VISIBLE : View.GONE);
        btnAdmin.setOnClickListener(v ->
                startActivity(new Intent(requireContext(), AdminActivity.class)));

        btnLogout.setOnClickListener(v -> {
            session.signOut();
            Intent i = new Intent(requireContext(), LoginActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            requireActivity().finish();
        });
    }
}
