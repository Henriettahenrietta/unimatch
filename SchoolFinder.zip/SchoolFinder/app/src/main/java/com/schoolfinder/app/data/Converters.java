package com.schoolfinder.app.data;

import androidx.room.TypeConverter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Stores List<String> as a single delimited column (mirrors the SRS array fields). */
public class Converters {

    private static final String SEP = "\\|\\|"; // regex for split
    private static final String JOIN = "||";

    @TypeConverter
    public static String fromList(List<String> list) {
        if (list == null || list.isEmpty()) return "";
        return String.join(JOIN, list);
    }

    @TypeConverter
    public static List<String> toList(String value) {
        if (value == null || value.isEmpty()) return new ArrayList<>();
        return new ArrayList<>(Arrays.asList(value.split(SEP)));
    }
}
