package com.schoolfinder.app.data;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ReviewDao {

    @Query("SELECT * FROM reviews WHERE schoolId = :schoolId AND approved = 1 ORDER BY timestamp DESC")
    LiveData<List<ReviewEntity>> observeApprovedForSchool(int schoolId);

    @Query("SELECT * FROM reviews ORDER BY timestamp DESC")
    LiveData<List<ReviewEntity>> observeAll();

    @Query("SELECT COUNT(*) FROM reviews")
    int count();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(ReviewEntity review);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<ReviewEntity> reviews);

    @Update
    void update(ReviewEntity review);

    @Delete
    void delete(ReviewEntity review);
}
