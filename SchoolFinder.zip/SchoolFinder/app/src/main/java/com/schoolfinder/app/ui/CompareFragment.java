package com.schoolfinder.app.ui;

import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.button.MaterialButton;
import com.schoolfinder.app.R;
import com.schoolfinder.app.data.Repository;
import com.schoolfinder.app.data.SchoolEntity;

import java.util.ArrayList;
import java.util.List;

public class CompareFragment extends Fragment {

    private final List<SchoolEntity> schools = new ArrayList<>();
    private SchoolEntity a, b;

    private LinearLayout compareContainer, openRow;
    private View cardCompare;
    private TextView tvHint;
    private MaterialButton btnPickA, btnPickB, btnOpenA, btnOpenB;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_compare, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        Repository repo = Repository.getInstance(requireContext());

        compareContainer = view.findViewById(R.id.compareContainer);
        openRow = view.findViewById(R.id.openRow);
        cardCompare = view.findViewById(R.id.cardCompare);
        tvHint = view.findViewById(R.id.tvHint);
        btnPickA = view.findViewById(R.id.btnPickA);
        btnPickB = view.findViewById(R.id.btnPickB);
        btnOpenA = view.findViewById(R.id.btnOpenA);
        btnOpenB = view.findViewById(R.id.btnOpenB);

        btnPickA.setOnClickListener(v -> showPicker(true));
        btnPickB.setOnClickListener(v -> showPicker(false));
        btnOpenA.setOnClickListener(v -> { if (a != null) SchoolDetailActivity.start(requireContext(), a.id); });
        btnOpenB.setOnClickListener(v -> { if (b != null) SchoolDetailActivity.start(requireContext(), b.id); });

        repo.observeSchools().observe(getViewLifecycleOwner(), list -> {
            schools.clear();
            if (list != null) schools.addAll(list);
        });
    }

    private void showPicker(final boolean isA) {
        if (schools.isEmpty()) return;
        MaterialButton anchor = isA ? btnPickA : btnPickB;
        PopupMenu menu = new PopupMenu(requireContext(), anchor);
        for (int i = 0; i < schools.size(); i++) {
            menu.getMenu().add(0, i, i, schools.get(i).name);
        }
        menu.setOnMenuItemClickListener(item -> {
            SchoolEntity picked = schools.get(item.getItemId());
            if (isA) { a = picked; btnPickA.setText(picked.name); }
            else { b = picked; btnPickB.setText(picked.name); }
            renderComparison();
            return true;
        });
        menu.show();
    }

    private void renderComparison() {
        if (a == null || b == null) return;
        tvHint.setVisibility(View.GONE);
        cardCompare.setVisibility(View.VISIBLE);
        openRow.setVisibility(View.VISIBLE);

        compareContainer.removeAllViews();
        addHeaderRow(a.name, b.name);
        addRow("Category", str(a.category), str(b.category), 0);
        addRow("Location", str(a.location), str(b.location), 0);
        addRow("Tuition", "$" + a.tuition, "$" + b.tuition,
                a.tuition == b.tuition ? 0 : (a.tuition < b.tuition ? 1 : 2));
        addRow("Rating", String.format("%.1f", a.baseRating), String.format("%.1f", b.baseRating),
                a.baseRating == b.baseRating ? 0 : (a.baseRating > b.baseRating ? 1 : 2));
        addRow("Programs", count(a.programs), count(b.programs), 0);
        addRow("Facilities", count(a.facilities), count(b.facilities), 0);
    }

    private void addHeaderRow(String nameA, String nameB) {
        LinearLayout row = baseRow();
        row.addView(cell("", 1f, false, false));
        row.addView(cell(nameA, 1.4f, true, false));
        row.addView(cell(nameB, 1.4f, true, false));
        compareContainer.addView(row);
        divider();
    }

    private void addRow(String label, String va, String vb, int better) {
        LinearLayout row = baseRow();
        row.addView(cell(label, 1f, true, false));
        row.addView(cell(va, 1.4f, false, better == 1));
        row.addView(cell(vb, 1.4f, false, better == 2));
        compareContainer.addView(row);
        divider();
    }

    private LinearLayout baseRow() {
        LinearLayout row = new LinearLayout(requireContext());
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        int pad = (int) UiUtils.dp(requireContext(), 6);
        row.setPadding(0, pad, 0, pad);
        return row;
    }

    private TextView cell(String text, float weight, boolean bold, boolean highlight) {
        TextView tv = new TextView(requireContext());
        tv.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, weight));
        tv.setText(text);
        tv.setGravity(Gravity.START);
        if (highlight) {
            tv.setTextColor(ContextCompat.getColor(requireContext(), R.color.maroon));
            tv.setTypeface(null, Typeface.BOLD);
        } else if (bold) {
            tv.setTextColor(ContextCompat.getColor(requireContext(), R.color.on_surface));
            tv.setTypeface(null, Typeface.BOLD);
        } else {
            tv.setTextColor(ContextCompat.getColor(requireContext(), R.color.on_surface));
        }
        return tv;
    }

    private void divider() {
        View v = new View(requireContext());
        v.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (int) UiUtils.dp(requireContext(), 1)));
        v.setBackgroundColor(ContextCompat.getColor(requireContext(), R.color.surface_variant));
        compareContainer.addView(v);
    }

    private String str(String s) { return s == null ? "-" : s; }
    private String count(List<String> l) { return l == null ? "0" : String.valueOf(l.size()); }
}
