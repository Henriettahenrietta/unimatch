package com.schoolfinder.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.schoolfinder.app.R;
import com.schoolfinder.app.data.Repository;
import com.schoolfinder.app.data.ReviewEntity;
import com.schoolfinder.app.data.SchoolEntity;
import com.schoolfinder.app.data.UserEntity;
import com.schoolfinder.app.session.SessionManager;
import com.schoolfinder.app.session.UserSession;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AdminActivity extends AppCompatActivity {

    private Repository repo;
    private final Map<Integer, String> schoolNames = new HashMap<>();

    private TextView noReviews;
    private LinearLayout reviewsContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        UserSession current = SessionManager.getInstance(this).getCurrent();
        if (current == null || !current.isAdmin()) {
            Toast.makeText(this, getString(R.string.admins_only), Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        setContentView(R.layout.activity_admin);
        repo = Repository.getInstance(this);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        setStat(R.id.statSchools, "0", getString(R.string.stat_schools));
        setStat(R.id.statStudents, "0", getString(R.string.stat_students));
        setStat(R.id.statReviews, "0", getString(R.string.stat_reviews));
        setStat(R.id.statAvg, "0.0", getString(R.string.stat_avg));

        MaterialButton btnManage = findViewById(R.id.btnManage);
        btnManage.setOnClickListener(v ->
                startActivity(new Intent(this, ManageSchoolsActivity.class)));

        noReviews = findViewById(R.id.tvNoReviews);
        reviewsContainer = findViewById(R.id.reviewsContainer);

        repo.observeSchools().observe(this, schools -> {
            schoolNames.clear();
            int count = 0;
            if (schools != null) {
                count = schools.size();
                for (SchoolEntity s : schools) schoolNames.put(s.id, s.name);
            }
            setStat(R.id.statSchools, String.valueOf(count), getString(R.string.stat_schools));
        });

        repo.observeUsers().observe(this, users -> {
            int students = 0;
            if (users != null) {
                for (UserEntity u : users) if (!"ADMIN".equals(u.role)) students++;
            }
            setStat(R.id.statStudents, String.valueOf(students), getString(R.string.stat_students));
        });

        repo.observeAllReviews().observe(this, reviews -> {
            int count = reviews == null ? 0 : reviews.size();
            double avg = 0;
            if (count > 0) {
                double sum = 0;
                for (ReviewEntity r : reviews) sum += r.rating;
                avg = sum / count;
            }
            setStat(R.id.statReviews, String.valueOf(count), getString(R.string.stat_reviews));
            setStat(R.id.statAvg, String.format("%.1f", avg), getString(R.string.stat_avg));
            renderModeration(reviews);
        });
    }

    private void renderModeration(List<ReviewEntity> reviews) {
        reviewsContainer.removeAllViews();
        int n = reviews == null ? 0 : reviews.size();
        noReviews.setVisibility(n == 0 ? View.VISIBLE : View.GONE);
        if (n == 0) return;

        LayoutInflater inflater = LayoutInflater.from(this);
        for (final ReviewEntity r : reviews) {
            View row = inflater.inflate(R.layout.item_admin_review, reviewsContainer, false);
            String schoolName = schoolNames.containsKey(r.schoolId)
                    ? schoolNames.get(r.schoolId) : getString(R.string.school_hash, r.schoolId);
            ((TextView) row.findViewById(R.id.tvSchool)).setText(schoolName);
            ((TextView) row.findViewById(R.id.tvUser)).setText(getString(R.string.by_user, r.userName));
            ((TextView) row.findViewById(R.id.tvComment)).setText(r.comment);
            UiUtils.renderStars(row.findViewById(R.id.starRow), r.rating, 14);

            MaterialButton btnApprove = row.findViewById(R.id.btnApprove);
            btnApprove.setText(getString(r.approved ? R.string.approved : R.string.hidden));
            btnApprove.setOnClickListener(v -> {
                r.approved = !r.approved;
                repo.updateReview(r);
            });

            row.findViewById(R.id.btnDelete).setOnClickListener(v -> repo.deleteReview(r));
            reviewsContainer.addView(row);
        }
    }

    private void setStat(int includeId, String value, String label) {
        View card = findViewById(includeId);
        if (card == null) return;
        TextView v = card.findViewById(R.id.statValue);
        TextView l = card.findViewById(R.id.statLabel);
        if (v != null) v.setText(value);
        if (l != null) l.setText(label);
    }
}
