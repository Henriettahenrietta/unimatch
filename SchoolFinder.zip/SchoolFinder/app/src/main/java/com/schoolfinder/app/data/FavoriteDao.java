package com.schoolfinder.app.data;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface FavoriteDao {

    @Query("SELECT schoolId FROM favorites WHERE userEmail = :email")
    LiveData<List<Integer>> observeIdsForUser(String email);

    @Query("SELECT schoolId FROM favorites WHERE userEmail = :email")
    List<Integer> idsForUserSync(String email);

    @Query("SELECT * FROM favorites WHERE userEmail = :email AND schoolId = :schoolId LIMIT 1")
    FavoriteEntity findSync(String email, int schoolId);

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(FavoriteEntity favorite);

    @Query("DELETE FROM favorites WHERE userEmail = :email AND schoolId = :schoolId")
    void remove(String email, int schoolId);
}
