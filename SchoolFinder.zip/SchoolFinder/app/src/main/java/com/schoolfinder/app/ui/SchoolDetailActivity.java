package com.schoolfinder.app.ui;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.DrawableCompat;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.TextInputEditText;
import com.schoolfinder.app.R;
import com.schoolfinder.app.data.Repository;
import com.schoolfinder.app.data.ReviewEntity;
import com.schoolfinder.app.data.SchoolEntity;
import com.schoolfinder.app.session.SessionManager;
import com.schoolfinder.app.session.UserSession;

import java.text.SimpleDateFormat;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class SchoolDetailActivity extends AppCompatActivity {

    private static final String EXTRA_ID = "school_id";

    public static void start(Context context, int schoolId) {
        Intent i = new Intent(context, SchoolDetailActivity.class);
        i.putExtra(EXTRA_ID, schoolId);
        context.startActivity(i);
    }

    private Repository repo;
    private int schoolId;
    private SchoolEntity school;
    private boolean guest;
    private String email;

    private int selectedRating = 5;
    private final Set<Integer> favIds = new HashSet<>();
    private MenuItem favItem;

    private LinearLayout starRow, facilitiesContainer, reviewsContainer, ratingSelector;
    private TextView tvName, tvCategory, tvAddress, tvTuition, tvDescription, header,
            tvReviewsHeader, tvNoReviews;
    private ChipGroup chipPrograms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_school_detail);

        repo = Repository.getInstance(this);
        schoolId = getIntent().getIntExtra(EXTRA_ID, -1);

        UserSession current = SessionManager.getInstance(this).getCurrent();
        guest = current == null || current.isGuest();
        email = current == null ? "guest" : current.email;

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());
        if (!guest) {
            favItem = toolbar.getMenu().add(getString(R.string.favorite));
            favItem.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
            updateFavIcon(false);
            toolbar.setOnMenuItemClickListener(item -> {
                repo.toggleFavorite(email, schoolId);
                return true;
            });
        }

        header = findViewById(R.id.header);
        tvName = findViewById(R.id.tvName);
        tvCategory = findViewById(R.id.tvCategory);
        starRow = findViewById(R.id.starRow);
        tvAddress = findViewById(R.id.tvAddress);
        tvTuition = findViewById(R.id.tvTuition);
        tvDescription = findViewById(R.id.tvDescription);
        chipPrograms = findViewById(R.id.chipPrograms);
        facilitiesContainer = findViewById(R.id.facilitiesContainer);
        reviewsContainer = findViewById(R.id.reviewsContainer);
        tvReviewsHeader = findViewById(R.id.tvReviewsHeader);
        tvNoReviews = findViewById(R.id.tvNoReviews);
        ratingSelector = findViewById(R.id.ratingSelector);

        MaterialButton btnMaps = findViewById(R.id.btnMaps);
        MaterialButton btnCall = findViewById(R.id.btnCall);
        MaterialButton btnWebsite = findViewById(R.id.btnWebsite);
        View cardAddReview = findViewById(R.id.cardAddReview);
        View cardGuestNote = findViewById(R.id.cardGuestNote);
        MaterialButton btnSubmit = findViewById(R.id.btnSubmitReview);
        TextInputEditText etComment = findViewById(R.id.etComment);

        cardAddReview.setVisibility(guest ? View.GONE : View.VISIBLE);
        cardGuestNote.setVisibility(guest ? View.VISIBLE : View.GONE);
        if (!guest) buildRatingSelector();

        btnMaps.setOnClickListener(v -> openMaps());
        btnCall.setOnClickListener(v -> {
            if (school == null || school.phone == null || school.phone.isEmpty()) {
                Toast.makeText(this, getString(R.string.no_phone), Toast.LENGTH_SHORT).show();
                return;
            }
            startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + school.phone)));
        });
        btnWebsite.setOnClickListener(v -> openWebsite());

        btnSubmit.setOnClickListener(v -> {
            String comment = etComment.getText() == null ? "" : etComment.getText().toString().trim();
            if (comment.isEmpty()) {
                Toast.makeText(this, getString(R.string.please_write_comment), Toast.LENGTH_SHORT).show();
                return;
            }
            UserSession cur = SessionManager.getInstance(this).getCurrent();
            String userName = cur == null ? "Student" : cur.name;
            repo.addReview(new ReviewEntity(schoolId, userName, selectedRating, comment,
                    true, System.currentTimeMillis()));
            etComment.setText("");
            selectedRating = 5;
            buildRatingSelector();
            Toast.makeText(this, getString(R.string.review_submitted), Toast.LENGTH_SHORT).show();
        });

        repo.observeSchool(schoolId).observe(this, s -> {
            if (s == null) return;
            school = s;
            bindSchool();
        });

        repo.observeReviewsForSchool(schoolId).observe(this, this::bindReviews);

        if (!guest) {
            repo.observeFavoriteIds(email).observe(this, ids -> {
                favIds.clear();
                if (ids != null) favIds.addAll(ids);
                updateFavIcon(favIds.contains(schoolId));
            });
        }
    }

    private void bindSchool() {
        header.setText(UiUtils.initials(school.name));
        UiUtils.tintAvatar(header, school.name);
        tvName.setText(school.name);
        tvCategory.setText(school.category);
        tvAddress.setText(school.address);
        tvTuition.setText(getString(R.string.tuition_per_year, UiUtils.money(school.tuition)));
        tvDescription.setText(school.description);
        UiUtils.renderStars(starRow, school.baseRating, 20);

        chipPrograms.removeAllViews();
        if (school.programs != null) {
            for (String p : school.programs) {
                Chip chip = new Chip(this);
                chip.setText(p);
                chip.setClickable(false);
                chipPrograms.addView(chip);
            }
        }

        facilitiesContainer.removeAllViews();
        if (school.facilities != null) {
            for (String f : school.facilities) {
                TextView tv = new TextView(this);
                tv.setText("•  " + f);
                tv.setTextColor(ContextCompat.getColor(this, R.color.on_surface));
                int pad = (int) UiUtils.dp(this, 2);
                tv.setPadding(0, pad, 0, pad);
                facilitiesContainer.addView(tv);
            }
        }
    }

    private void bindReviews(List<ReviewEntity> reviews) {
        reviewsContainer.removeAllViews();
        int n = reviews == null ? 0 : reviews.size();
        tvReviewsHeader.setText(getString(R.string.reviews_count, n));
        tvNoReviews.setVisibility(n == 0 ? View.VISIBLE : View.GONE);

        if (school != null) {
            double combined = school.baseRating;
            if (n > 0) {
                double sum = 0;
                for (ReviewEntity r : reviews) sum += r.rating;
                double reviewAvg = sum / n;
                combined = (school.baseRating + reviewAvg) / 2.0;
            }
            UiUtils.renderStars(starRow, combined, 20);
        }

        if (n == 0) return;
        SimpleDateFormat fmt = new SimpleDateFormat("MMM d, yyyy", Locale.getDefault());
        LayoutInflater inflater = LayoutInflater.from(this);
        for (ReviewEntity r : reviews) {
            View row = inflater.inflate(R.layout.item_review, reviewsContainer, false);
            ((TextView) row.findViewById(R.id.tvUser)).setText(r.userName);
            ((TextView) row.findViewById(R.id.tvDate)).setText(fmt.format(r.timestamp));
            ((TextView) row.findViewById(R.id.tvComment)).setText(r.comment);
            UiUtils.renderStars(row.findViewById(R.id.starRow), r.rating, 14);
            reviewsContainer.addView(row);
        }
    }

    private void buildRatingSelector() {
        ratingSelector.removeAllViews();
        int size = (int) UiUtils.dp(this, 32);
        for (int i = 1; i <= 5; i++) {
            final int value = i;
            ImageView star = new ImageView(this);
            star.setImageResource(i <= selectedRating ? R.drawable.ic_star : R.drawable.ic_star_border);
            star.setColorFilter(0xFFFFB300, PorterDuff.Mode.SRC_IN);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(size, size);
            star.setLayoutParams(lp);
            star.setOnClickListener(v -> {
                selectedRating = value;
                buildRatingSelector();
            });
            ratingSelector.addView(star);
        }
    }

    private void updateFavIcon(boolean fav) {
        if (favItem == null) return;
        Drawable d = ContextCompat.getDrawable(this,
                fav ? R.drawable.ic_favorite : R.drawable.ic_favorite_border);
        if (d != null) {
            d = DrawableCompat.wrap(d.mutate());
            DrawableCompat.setTint(d, ContextCompat.getColor(this, R.color.white));
            favItem.setIcon(d);
        }
    }

    private void openMaps() {
        if (school == null) return;
        String label = Uri.encode(school.name);
        Uri geo = Uri.parse("geo:" + school.latitude + "," + school.longitude
                + "?q=" + school.latitude + "," + school.longitude + "(" + label + ")");
        Intent intent = new Intent(Intent.ACTION_VIEW, geo);
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            String url = "https://www.google.com/maps/search/?api=1&query="
                    + school.latitude + "," + school.longitude;
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        }
    }

    private void openWebsite() {
        if (school == null || school.website == null || school.website.isEmpty()) {
            Toast.makeText(this, getString(R.string.no_website), Toast.LENGTH_SHORT).show();
            return;
        }
        String url = school.website;
        if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://" + url;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, getString(R.string.no_browser), Toast.LENGTH_SHORT).show();
        }
    }
}
