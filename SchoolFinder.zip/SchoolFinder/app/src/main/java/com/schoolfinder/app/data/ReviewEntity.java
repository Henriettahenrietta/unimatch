package com.schoolfinder.app.data;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "reviews")
public class ReviewEntity {

    @PrimaryKey(autoGenerate = true)
    public int id;

    public int schoolId;
    public String userName;
    public int rating;             // 1..5
    public String comment;
    public boolean approved;       // admins can moderate (approve/hide/delete)
    public long timestamp;

    public ReviewEntity(int schoolId, String userName, int rating, String comment,
                        boolean approved, long timestamp) {
        this.schoolId = schoolId;
        this.userName = userName;
        this.rating = rating;
        this.comment = comment;
        this.approved = approved;
        this.timestamp = timestamp;
    }

    @Ignore
    public ReviewEntity() {
    }
}
