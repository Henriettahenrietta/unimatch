package com.schoolfinder.app.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.schoolfinder.app.R;
import com.schoolfinder.app.adapter.SchoolAdapter;
import com.schoolfinder.app.data.Repository;
import com.schoolfinder.app.data.SchoolEntity;
import com.schoolfinder.app.session.SessionManager;
import com.schoolfinder.app.session.UserSession;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class FavoritesFragment extends Fragment {

    private Repository repo;
    private SchoolAdapter adapter;
    private RecyclerView recycler;
    private TextView tvEmpty;

    private List<SchoolEntity> allSchools = new ArrayList<>();
    private final Set<Integer> favIds = new HashSet<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_favorites, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        repo = Repository.getInstance(requireContext());
        SessionManager session = SessionManager.getInstance(requireContext());

        recycler = view.findViewById(R.id.recycler);
        tvEmpty = view.findViewById(R.id.tvEmpty);
        recycler.setLayoutManager(new LinearLayoutManager(requireContext()));

        UserSession current = session.getCurrent();
        boolean guest = current == null || current.isGuest();
        final String email = current == null ? "guest" : current.email;

        if (guest) {
            recycler.setVisibility(View.GONE);
            tvEmpty.setVisibility(View.VISIBLE);
            tvEmpty.setText(getString(R.string.fav_guest_prompt));
            return;
        }

        adapter = new SchoolAdapter(new SchoolAdapter.Listener() {
            @Override
            public void onClick(SchoolEntity school) {
                SchoolDetailActivity.start(requireContext(), school.id);
            }

            @Override
            public void onToggleFavorite(SchoolEntity school) {
                repo.toggleFavorite(email, school.id);
            }
        });
        adapter.setShowFavorite(true);
        recycler.setAdapter(adapter);

        repo.observeSchools().observe(getViewLifecycleOwner(), schools -> {
            allSchools = schools == null ? new ArrayList<>() : schools;
            render();
        });
        repo.observeFavoriteIds(email).observe(getViewLifecycleOwner(), ids -> {
            favIds.clear();
            if (ids != null) favIds.addAll(ids);
            adapter.setFavorites(new ArrayList<>(favIds));
            render();
        });
    }

    private void render() {
        if (adapter == null) return;
        List<SchoolEntity> favs = new ArrayList<>();
        for (SchoolEntity s : allSchools) {
            if (favIds.contains(s.id)) favs.add(s);
        }
        adapter.setItems(favs);
        boolean empty = favs.isEmpty();
        recycler.setVisibility(empty ? View.GONE : View.VISIBLE);
        tvEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
        if (empty) tvEmpty.setText(getString(R.string.fav_empty));
    }
}
