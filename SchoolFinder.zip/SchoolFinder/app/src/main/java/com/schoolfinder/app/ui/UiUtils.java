package com.schoolfinder.app.ui;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.schoolfinder.app.R;

public final class UiUtils {

    private UiUtils() {}

    private static final int[] SWATCHES = new int[]{
            0xFF800000, 0xFF9A1B2F, 0xFF6E1423, 0xFFB23A48,
            0xFF5C0000, 0xFFA52A2A, 0xFF7B1E1E, 0xFF8B2942
    };

    public static int colorForName(String seed) {
        if (seed == null) seed = "";
        int idx = Math.abs(seed.hashCode()) % SWATCHES.length;
        return SWATCHES[idx];
    }

    public static String initials(String name) {
        if (name == null || name.trim().isEmpty()) return "?";
        String[] parts = name.trim().split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.length && sb.length() < 2; i++) {
            if (!parts[i].isEmpty()) sb.append(Character.toUpperCase(parts[i].charAt(0)));
        }
        return sb.length() == 0 ? "?" : sb.toString();
    }

    /** Tints a rounded avatar background with a deterministic maroon shade. */
    public static void tintAvatar(View avatar, String seed) {
        int color = colorForName(seed);
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setCornerRadius(dp(avatar.getContext(), 12));
        gd.setColor(color);
        avatar.setBackground(gd);
    }

    /** Renders a 5-star row reflecting a 0..5 rating into the given container. */
    public static void renderStars(LinearLayout container, double rating, int sizeDp) {
        Context ctx = container.getContext();
        container.removeAllViews();
        int full = (int) Math.floor(rating);
        boolean half = (rating - full) >= 0.5;
        int size = (int) dp(ctx, sizeDp);
        int amber = 0xFFFFB300;
        for (int i = 1; i <= 5; i++) {
            ImageView star = new ImageView(ctx);
            int res;
            if (i <= full) res = R.drawable.ic_star;
            else if (i == full + 1 && half) res = R.drawable.ic_star_half;
            else res = R.drawable.ic_star_border;
            star.setImageResource(res);
            star.setColorFilter(amber, PorterDuff.Mode.SRC_IN);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(size, size);
            star.setLayoutParams(lp);
            container.addView(star);
        }
    }

    public static float dp(Context ctx, int dp) {
        return dp * ctx.getResources().getDisplayMetrics().density;
    }

    /** Formats an amount as FCFA with thousands separators, e.g. 1500000 -> "1,500,000 FCFA". */
    public static String money(int amount) {
        return String.format(java.util.Locale.US, "%,d FCFA", amount);
    }

    /** Maps a stored (English) category to the user's current language for display. */
    public static String localizedCategory(Context ctx, String raw) {
        if (raw == null || raw.isEmpty()) return raw;
        switch (raw) {
            case "University": return ctx.getString(R.string.cat_university);
            case "Engineering School": return ctx.getString(R.string.cat_engineering_school);
            case "High School": return ctx.getString(R.string.cat_high_school);
            case "Teacher Training": return ctx.getString(R.string.cat_teacher_training);
            case "University Institute": return ctx.getString(R.string.cat_university_institute);
            default: return raw;
        }
    }
}
