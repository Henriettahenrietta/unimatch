package com.schoolfinder.app.data;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Initial content so the app is useful on first launch (institutions in Cameroon). */
public final class SeedData {

    private SeedData() {}

    public static List<SchoolEntity> schools() {
        List<SchoolEntity> list = new ArrayList<>();

        list.add(new SchoolEntity(
                "University of Yaoundé I", "University", "Yaoundé", "Ngoa-Ekelle, Yaoundé",
                3.8667, 11.5167, 1000,
                Arrays.asList("Science", "Medicine", "Arts", "Education"),
                Arrays.asList("Library", "Laboratories", "Hostels", "Sports complex"),
                "The oldest and one of the largest state universities in Cameroon, strong in sciences and medicine.",
                4.5, "https://uy1.uninet.cm", "+237222234834"));

        list.add(new SchoolEntity(
                "University of Buea", "University", "Buea", "Molyko, Buea, South-West",
                4.1559, 9.2632, 1200,
                Arrays.asList("Arts", "Science", "Engineering", "Health Sciences"),
                Arrays.asList("Library", "Computer labs", "Cafeteria", "Health centre"),
                "Cameroon's reference Anglo-Saxon university, known for its vibrant Molyko student town.",
                4.4, "https://ubuea.cm", "+237233322134"));

        list.add(new SchoolEntity(
                "University of Douala", "University", "Douala", "BP 2701, Douala, Littoral",
                4.0511, 9.7679, 1100,
                Arrays.asList("Economics", "Management", "Science", "Engineering"),
                Arrays.asList("Library", "Auditorium", "Labs", "Sports field"),
                "A major university in Cameroon's economic capital with strong business and technology faculties.",
                4.1, "https://univ-douala.cm", "+237233401954"));

        list.add(new SchoolEntity(
                "National Advanced School of Engineering", "Engineering School", "Yaoundé",
                "Polytechnique, Melen, Yaoundé",
                3.8520, 11.4920, 1500,
                Arrays.asList("Civil Engineering", "Computer Engineering", "Electrical Engineering", "Telecommunications"),
                Arrays.asList("Engineering labs", "Library", "Workshops", "Wi-Fi campus"),
                "Elite engineering school (Polytechnique) of the University of Yaoundé I, highly competitive entry.",
                4.7, "https://polytechnique.cm", "+237222220134"));

        list.add(new SchoolEntity(
                "Catholic University of Central Africa", "University", "Yaoundé",
                "Nkolbisson, Yaoundé",
                3.8700, 11.4400, 2500,
                Arrays.asList("Law", "Economics", "Social Sciences", "Theology"),
                Arrays.asList("Library", "Chapel", "Modern classrooms", "Cafeteria"),
                "Reputable private Catholic university (UCAC) recognised across the CEMAC region.",
                4.3, "https://ucac-icy.net", "+237222315554"));

        list.add(new SchoolEntity(
                "University of Dschang", "University", "Dschang", "Foto, Dschang, West",
                5.4500, 10.0667, 1000,
                Arrays.asList("Agronomy", "Science", "Law", "Economics"),
                Arrays.asList("Botanical garden", "Library", "Laboratories", "Hostels"),
                "Renowned for agronomy and life sciences, set in the cool highlands of the West region.",
                4.2, "https://univ-dschang.org", "+237233451068"));

        list.add(new SchoolEntity(
                "ICT University", "University", "Yaoundé", "Messassi, Yaoundé",
                3.9300, 11.5400, 3000,
                Arrays.asList("Computer Science", "Information Technology", "Business", "Project Management"),
                Arrays.asList("Computer labs", "Wi-Fi campus", "Library", "Innovation hub"),
                "Private, technology-focused university offering American-style ICT and business programmes.",
                4.0, "https://ictuniversity.org", "+237242000222"));

        list.add(new SchoolEntity(
                "University of Bamenda", "University", "Bamenda", "Bambili, Bamenda, North-West",
                6.0000, 10.2500, 1000,
                Arrays.asList("Education", "Science", "Law", "Health Sciences"),
                Arrays.asList("Library", "Laboratories", "Sports complex", "Hostels"),
                "State university serving the North-West region, with teacher-training and science faculties.",
                3.9, "https://uniba.cm", "+237233362134"));

        list.add(new SchoolEntity(
                "Saint Monica University", "University", "Buea", "Buea, South-West",
                4.1600, 9.2400, 2800,
                Arrays.asList("Business", "Nursing", "Computer Science", "Public Health"),
                Arrays.asList("Library", "Computer labs", "Hostels", "Clinic"),
                "Private institution offering British-accredited programmes in business and health sciences.",
                3.8, "https://saintmonicauniversity.com", "+237677000111"));

        list.add(new SchoolEntity(
                "Government Bilingual High School Yaoundé", "High School", "Yaoundé",
                "Essos, Yaoundé",
                3.8800, 11.5300, 200,
                Arrays.asList("Sciences", "Arts", "Commercial"),
                Arrays.asList("Classrooms", "Library", "Sports field", "Science labs"),
                "Large public bilingual secondary school preparing students for the GCE and Baccalauréat.",
                4.0, "", "+237222210045"));

        return list;
    }

    public static List<ReviewEntity> sampleReviews() {
        long now = System.currentTimeMillis();
        long day = 86_400_000L;
        List<ReviewEntity> list = new ArrayList<>();
        list.add(new ReviewEntity(1, "Aline N.", 5, "Excellent science faculty and very affordable tuition.", true, now - day));
        list.add(new ReviewEntity(2, "Brian T.", 4, "Great campus life in Molyko, lecturers are supportive.", true, now - 2 * day));
        list.add(new ReviewEntity(4, "Eric M.", 5, "Hard to get in but the engineering training is world class.", true, now - 3 * day));
        list.add(new ReviewEntity(5, "Sandra K.", 4, "Beautiful campus and strong law programme.", true, now - 4 * day));
        list.add(new ReviewEntity(6, "Joseph F.", 4, "Loved the agronomy department and the cool weather.", true, now - 5 * day));
        return list;
    }

    public static UserEntity defaultAdmin() {
        return new UserEntity("Administrator", "admin@schoolfinder.com", "admin123", "ADMIN");
    }
}
