package com.schoolfinder.app.data;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Initial content so the app is useful on first launch (institutions in Yaoundé, Cameroon).
 *  Tuition values are approximate annual fees in FCFA (XAF). */
public final class SeedData {

    private SeedData() {}

    public static List<SchoolEntity> schools() {
        List<SchoolEntity> list = new ArrayList<>();

        list.add(new SchoolEntity(
                "University of Yaoundé I", "University", "Yaoundé", "Ngoa-Ekellé, Yaoundé",
                3.8634, 11.5012, 50000,
                Arrays.asList("Science", "Medicine", "Arts", "Education"),
                Arrays.asList("Library", "Laboratories", "Hostels", "Sports complex"),
                "The oldest and one of the largest state universities in Cameroon, strong in sciences and medicine.",
                4.5, "https://uy1.uninet.cm", "+237222234834"));

        list.add(new SchoolEntity(
                "University of Yaoundé II", "University", "Yaoundé", "Soa, Yaoundé",
                3.9833, 11.6167, 50000,
                Arrays.asList("Law", "Economics", "Political Science", "Management"),
                Arrays.asList("Library", "Lecture halls", "Cafeteria", "Hostels"),
                "State university based in Soa, focused on law, economics, and political and social sciences.",
                4.2, "https://universite-yaounde2.org", "+237222218401"));

        list.add(new SchoolEntity(
                "National Advanced School of Engineering", "Engineering School", "Yaoundé",
                "Polytechnique, Melen, Yaoundé",
                3.8520, 11.4920, 50000,
                Arrays.asList("Civil Engineering", "Computer Engineering", "Electrical Engineering", "Telecommunications"),
                Arrays.asList("Engineering labs", "Library", "Workshops", "Wi-Fi campus"),
                "Elite engineering school (Polytechnique) of the University of Yaoundé I, highly competitive entry.",
                4.7, "https://polytechnique.cm", "+237222220134"));

        list.add(new SchoolEntity(
                "Catholic University of Central Africa", "University", "Yaoundé",
                "Nkolbisson, Yaoundé",
                3.8700, 11.4400, 1500000,
                Arrays.asList("Law", "Economics", "Social Sciences", "Theology"),
                Arrays.asList("Library", "Chapel", "Modern classrooms", "Cafeteria"),
                "Reputable private Catholic university (UCAC) recognised across the CEMAC region.",
                4.3, "https://ucac-icy.net", "+237222315554"));

        list.add(new SchoolEntity(
                "Protestant University of Central Africa", "University", "Yaoundé",
                "Nlongkak, Yaoundé",
                3.8900, 11.5200, 1000000,
                Arrays.asList("Theology", "Health Sciences", "Management", "Law"),
                Arrays.asList("Library", "Computer labs", "Clinic", "Chapel"),
                "Private university (UPAC) offering theology, health sciences, law and management programmes.",
                4.0, "https://upac.education", "+237222204312"));

        list.add(new SchoolEntity(
                "ICT University", "University", "Yaoundé", "Messassi, Yaoundé",
                3.9300, 11.5400, 1800000,
                Arrays.asList("Computer Science", "Information Technology", "Business", "Project Management"),
                Arrays.asList("Computer labs", "Wi-Fi campus", "Library", "Innovation hub"),
                "Private, technology-focused university offering American-style ICT and business programmes.",
                4.0, "https://ictuniversity.org", "+237242000222"));

        list.add(new SchoolEntity(
                "Higher Teacher Training College (ENS Yaoundé)", "Teacher Training", "Yaoundé",
                "Ngoa-Ekellé, Yaoundé",
                3.8640, 11.5000, 50000,
                Arrays.asList("Science Education", "Arts Education", "Pedagogy", "Educational Sciences"),
                Arrays.asList("Library", "Lecture halls", "Laboratories", "Sports field"),
                "The flagship teacher-training college (ENS) of the University of Yaoundé I.",
                4.4, "https://ens.cm", "+237222234567"));

        list.add(new SchoolEntity(
                "National Advanced School of Posts, Telecommunications and ICT", "Engineering School", "Yaoundé",
                "Ngoa-Ekellé, Yaoundé",
                3.8480, 11.5020, 100000,
                Arrays.asList("Telecommunications", "Networks", "Software Engineering", "Postal Management"),
                Arrays.asList("Telecom labs", "Computer labs", "Library", "Wi-Fi campus"),
                "Specialist school (SUP'PTIC) training engineers and managers for telecoms, ICT and postal services.",
                4.3, "https://sup-ptic.cm", "+237222230101"));

        list.add(new SchoolEntity(
                "Siantou University Institute", "University Institute", "Yaoundé",
                "Nsam, Yaoundé",
                3.8400, 11.5150, 600000,
                Arrays.asList("Business", "Nursing", "Computer Science", "Accounting"),
                Arrays.asList("Library", "Computer labs", "Clinic", "Cafeteria"),
                "Well-known private higher institute (Siantou) offering professional programmes in central Yaoundé.",
                3.8, "https://siantou.com", "+237222311220"));

        list.add(new SchoolEntity(
                "Government Bilingual High School Yaoundé", "High School", "Yaoundé",
                "Essos, Yaoundé",
                3.8800, 11.5300, 25000,
                Arrays.asList("Sciences", "Arts", "Commercial"),
                Arrays.asList("Classrooms", "Library", "Sports field", "Science labs"),
                "Large public bilingual secondary school preparing students for the GCE and Baccalauréat.",
                4.0, "", "+237222210045"));

        return list;
    }

    public static List<ReviewEntity> sampleReviews() {
        long now = System.currentTimeMillis();
        long day = 86_400_000L;
        List<ReviewEntity> list = new ArrayList<>();
        list.add(new ReviewEntity(1, "Aline N.", 5, "Excellent science faculty and very affordable tuition.", true, now - day));
        list.add(new ReviewEntity(3, "Eric M.", 5, "Hard to get in but the engineering training is world class.", true, now - 2 * day));
        list.add(new ReviewEntity(4, "Sandra K.", 4, "Beautiful campus and a strong law programme.", true, now - 3 * day));
        list.add(new ReviewEntity(6, "Joseph F.", 4, "Modern computer labs and a great innovation hub.", true, now - 4 * day));
        list.add(new ReviewEntity(7, "Mireille D.", 5, "Top choice if you want to become a teacher; very well organised.", true, now - 5 * day));
        return list;
    }

    public static UserEntity defaultAdmin() {
        return new UserEntity("Administrator", "admin@schoolfinder.com", "admin123", "ADMIN");
    }
}
