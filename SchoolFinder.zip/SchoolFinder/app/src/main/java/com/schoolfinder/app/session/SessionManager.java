package com.schoolfinder.app.session;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {

    private static final String PREFS = "school_finder_session";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_NAME = "name";
    private static final String KEY_ROLE = "role";

    private final SharedPreferences prefs;
    private static volatile SessionManager INSTANCE;

    public static SessionManager getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (SessionManager.class) {
                if (INSTANCE == null) {
                    INSTANCE = new SessionManager(context.getApplicationContext());
                }
            }
        }
        return INSTANCE;
    }

    private SessionManager(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public UserSession getCurrent() {
        String email = prefs.getString(KEY_EMAIL, null);
        if (email == null) return null;
        String name = prefs.getString(KEY_NAME, "User");
        String role = prefs.getString(KEY_ROLE, "GUEST");
        return new UserSession(email, name, role);
    }

    public boolean isLoggedIn() {
        return prefs.contains(KEY_EMAIL);
    }

    public void signIn(UserSession session) {
        prefs.edit()
                .putString(KEY_EMAIL, session.email)
                .putString(KEY_NAME, session.name)
                .putString(KEY_ROLE, session.role)
                .apply();
    }

    public void continueAsGuest() {
        signIn(new UserSession("guest", "Guest", "GUEST"));
    }

    public void signOut() {
        prefs.edit().clear().apply();
    }
}
