package com.schoolfinder.app.data;

import android.content.Context;

import androidx.lifecycle.LiveData;

import com.schoolfinder.app.R;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Single access point to the local data layer. In a production build this would
 * call the Spring Boot REST APIs described in the SRS; here it talks to Room.
 * Reads that observe data return LiveData; writes run on a background executor.
 */
public class Repository {

    public interface Callback<T> {
        void onResult(T value);
    }

    private final SchoolDao schoolDao;
    private final UserDao userDao;
    private final ReviewDao reviewDao;
    private final FavoriteDao favoriteDao;
    private final android.content.Context appContext;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final android.os.Handler main = new android.os.Handler(android.os.Looper.getMainLooper());

    private static volatile Repository INSTANCE;

    public static Repository getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (Repository.class) {
                if (INSTANCE == null) {
                    INSTANCE = new Repository(context.getApplicationContext(), AppDatabase.getInstance(context));
                }
            }
        }
        return INSTANCE;
    }

    private Repository(android.content.Context context, AppDatabase db) {
        this.appContext = context;
        this.schoolDao = db.schoolDao();
        this.userDao = db.userDao();
        this.reviewDao = db.reviewDao();
        this.favoriteDao = db.favoriteDao();
    }

    public ExecutorService io() {
        return io;
    }

    private <T> void deliver(final Callback<T> cb, final T value) {
        if (cb != null) main.post(() -> cb.onResult(value));
    }

    // ---- Schools ----
    public LiveData<List<SchoolEntity>> observeSchools() {
        return schoolDao.observeAll();
    }

    public LiveData<SchoolEntity> observeSchool(int id) {
        return schoolDao.observeById(id);
    }

    public void addSchool(SchoolEntity s) {
        io.execute(() -> schoolDao.insert(s));
    }

    public void updateSchool(SchoolEntity s) {
        io.execute(() -> schoolDao.update(s));
    }

    public void deleteSchool(SchoolEntity s) {
        io.execute(() -> schoolDao.delete(s));
    }

    // ---- Users / Auth ----
    public LiveData<List<UserEntity>> observeUsers() {
        return userDao.observeAll();
    }

    public void login(final String email, final String password, final Callback<UserEntity> cb) {
        io.execute(() -> {
            UserEntity u = userDao.login(email.trim().toLowerCase(), password);
            deliver(cb, u);
        });
    }

    public void register(final String name, final String email, final String password,
                         final Callback<UserEntity> cb, final Callback<String> error) {
        io.execute(() -> {
            String clean = email.trim().toLowerCase();
            if (userDao.getByEmail(clean) != null) {
                if (error != null) main.post(() -> error.onResult(appContext.getString(R.string.email_exists)));
                return;
            }
            UserEntity user = new UserEntity(name.trim(), clean, password, "STUDENT");
            long id = userDao.insert(user);
            user.id = (int) id;
            deliver(cb, user);
        });
    }

    // ---- Reviews ----
    public LiveData<List<ReviewEntity>> observeReviewsForSchool(int schoolId) {
        return reviewDao.observeApprovedForSchool(schoolId);
    }

    public LiveData<List<ReviewEntity>> observeAllReviews() {
        return reviewDao.observeAll();
    }

    public void addReview(ReviewEntity r) {
        io.execute(() -> reviewDao.insert(r));
    }

    public void updateReview(ReviewEntity r) {
        io.execute(() -> reviewDao.update(r));
    }

    public void deleteReview(ReviewEntity r) {
        io.execute(() -> reviewDao.delete(r));
    }

    // ---- Favorites ----
    public LiveData<List<Integer>> observeFavoriteIds(String email) {
        return favoriteDao.observeIdsForUser(email);
    }

    public void toggleFavorite(final String email, final int schoolId) {
        io.execute(() -> {
            FavoriteEntity existing = favoriteDao.findSync(email, schoolId);
            if (existing == null) {
                favoriteDao.insert(new FavoriteEntity(email, schoolId));
            } else {
                favoriteDao.remove(email, schoolId);
            }
        });
    }
}
