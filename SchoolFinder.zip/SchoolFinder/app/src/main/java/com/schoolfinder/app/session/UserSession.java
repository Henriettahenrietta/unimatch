package com.schoolfinder.app.session;

/** Represents who is currently using the app. role can be STUDENT, ADMIN or GUEST. */
public class UserSession {
    public final String email;
    public final String name;
    public final String role;

    public UserSession(String email, String name, String role) {
        this.email = email;
        this.name = name;
        this.role = role;
    }

    public boolean isGuest() { return "GUEST".equals(role); }
    public boolean isAdmin() { return "ADMIN".equals(role); }
    public boolean isStudent() { return "STUDENT".equals(role); }
}
