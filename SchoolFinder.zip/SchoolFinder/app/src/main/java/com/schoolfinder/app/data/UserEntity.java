package com.schoolfinder.app.data;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "users", indices = {@Index(value = {"email"}, unique = true)})
public class UserEntity {

    @PrimaryKey(autoGenerate = true)
    public int id;

    public String name;
    @NonNull
    public String email;
    public String password;        // demo only: stored in plain text locally
    public String role;            // "STUDENT" or "ADMIN"

    public UserEntity(String name, @NonNull String email, String password, String role) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.role = role;
    }

    @Ignore
    public UserEntity() {
        this.email = "";
    }
}
